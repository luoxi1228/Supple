#include "OFR.hpp"
#include "helper.hpp"

#include <algorithm>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <chrono>
#include <cstdio>

#ifndef BEFTS_MODE
#include "/root/Supple/Enclave/oasm_lib.h"
#endif

namespace ofr
{

using detail::AddOverflowSize;
using detail::CtEqualU8;
using detail::CtLessSize;
using detail::CtMaxI64;
using detail::CtMinI64;
using detail::CtSelectU8;
using detail::LeftBit;
using detail::MulOverflowSize;
using detail::RightBit;
using detail::ValidateCapacities;
using detail::ValidateTags;

namespace
{

struct CapacitySplit
{
  size_t n_top;
  size_t n_bottom;
  size_t top_left;
  size_t top_right;
  size_t bottom_left;
  size_t bottom_right;
};

CapacitySplit SplitCapacities(size_t n, size_t n_left, size_t n_right)
{
  const size_t n_top = n / 2 + n % 2;
  const size_t top_left = n_left / 2 + n_left % 2;
  const size_t top_right = n_top - top_left;
  CapacitySplit split = {
      n_top,
      n / 2,
      top_left,
      top_right,
      n_left - top_left,
      n_right - top_right};
  return split;
}

size_t OFRControlCountImpl(size_t n, size_t n_left, size_t n_right)
{
  if (n_left == 0 || n_right == 0)
    return 0;
  if (n >= 2 && (n & (n - 1)) == 0 &&
      n_left == n / 2 && n_right == n / 2)
  {
    size_t depth = 0;
    for (size_t length = n; length > 1; length >>= 1U)
      ++depth;
    size_t count = 0;
    if (MulOverflowSize(n / 2, depth, &count))
      throw std::length_error("OFR control count overflow");
    return count;
  }
  if (n == 2)
    return 1;

  const CapacitySplit split = SplitCapacities(n, n_left, n_right);
  const size_t top_count = OFRControlCountImpl(
      split.n_top, split.top_left, split.top_right);
  const size_t bottom_count = OFRControlCountImpl(
      split.n_bottom, split.bottom_left, split.bottom_right);

  size_t result = 0;
  if (AddOverflowSize(n / 2, top_count, &result) ||
      AddOverflowSize(result, bottom_count, &result))
    throw std::length_error("OFR control count overflow");
  return result;
}

size_t OFRBalanceInPlaceImpl(uint8_t *tags, PackedControls &controls, uint8_t *scratch,
                             size_t base, size_t stride, size_t n,
                             size_t n_left, size_t n_right, size_t position);

size_t OFRControlWriteImpl(uint8_t *tags, PackedControls &controls, uint8_t *scratch,
                           size_t base, size_t stride, size_t n,
                           size_t n_left, size_t n_right, size_t position)
{
  if (n_left == 0 || n_right == 0)
    return position;

  if (n == 2)
  {
    // Exact (1,1) responsibilities make the second tag the two-bit complement
    // of the first: 00/11 -> copy second, 01/10 -> swap, and vice versa.
    const uint8_t x = tags[base];
    controls[position] = static_cast<uint8_t>(OFR_TAG_BOTH ^ x);
    tags[base] = OFR_TAG_LEFT;
    tags[base + stride] = OFR_TAG_RIGHT;
    return position + 1;
  }

  position = OFRBalanceInPlaceImpl(
      tags, controls, scratch, base, stride, n, n_left, n_right, position);

  const CapacitySplit split = SplitCapacities(n, n_left, n_right);
  position = OFRControlWriteImpl(tags, controls, scratch, base, stride * 2,
                                 split.n_top,
                                 split.top_left,
                                 split.top_right,
                                 position);
  return OFRControlWriteImpl(tags, controls, scratch, base + stride, stride * 2,
                             split.n_bottom,
                             split.bottom_left,
                             split.bottom_right,
                             position);
}

// The two recursive children occupy the even and odd record lanes. Recurse
// with a doubled stride instead of materializing either child in a vector.
size_t OFRApplyStrided(unsigned char *data,
                       PackedControlView controls,
                       size_t n,
                       size_t n_left,
                       size_t n_right,
                       size_t block_size,
                       size_t stride,
                       size_t position)
{
  if (n_left == 0 || n_right == 0)
    return position;

  const size_t byte_stride = stride * block_size;
  PackedControlCursor cursor(controls, position);
  if (n == 2)
  {
    detail::ApplyOFork(data, data + byte_stride, block_size, cursor.nextUnchecked());
    return position + 1;
  }

  const size_t gate_count = n / 2;
  for (size_t gate = 0; gate < gate_count; ++gate)
  {
    unsigned char *first = data + (2 * gate) * byte_stride;
    detail::ApplyOFork(first,
                       first + byte_stride,
                       block_size,
                       cursor.nextUnchecked());
  }
  position += gate_count;

  const CapacitySplit split = SplitCapacities(n, n_left, n_right);
  position = OFRApplyStrided(data,
                             controls,
                             split.n_top,
                             split.top_left,
                             split.top_right,
                             block_size,
                             stride * 2,
                             position);
  return OFRApplyStrided(data + byte_stride,
                          controls,
                          split.n_bottom,
                          split.bottom_left,
                          split.bottom_right,
                          block_size,
                          stride * 2,
                          position);
}

size_t OFRApplyWordsStrided(size_t *rows, size_t words_per_row,
                            PackedControlView controls, size_t n,
                            size_t n_left, size_t n_right,
                            size_t stride, size_t position)
{
  if (n_left == 0 || n_right == 0)
    return position;

  const size_t word_stride = stride * words_per_row;
  PackedControlCursor cursor(controls, position);
  const size_t gate_count = n / 2;
  for (size_t gate = 0; gate < gate_count; ++gate)
  {
    size_t *first = rows + (2 * gate) * word_stride;
    size_t *second = first + word_stride;
    const uint8_t control = cursor.nextUnchecked();
    const size_t top_mask = size_t(0) - size_t((control >> 1U) & 1U);
    const size_t bottom_mask = size_t(0) - size_t(control & 1U);
    for (size_t word = 0; word < words_per_row; ++word)
    {
      const size_t x = first[word];
      const size_t y = second[word];
      first[word] = (x & ~top_mask) | (y & top_mask);
      second[word] = (x & ~bottom_mask) | (y & bottom_mask);
    }
  }
  position += gate_count;
  if (n == 2)
    return position;

  const CapacitySplit split = SplitCapacities(n, n_left, n_right);
  position = OFRApplyWordsStrided(
      rows, words_per_row, controls, split.n_top, split.top_left,
      split.top_right, stride * 2, position);
  return OFRApplyWordsStrided(
      rows + word_stride, words_per_row, controls, split.n_bottom,
      split.bottom_left, split.bottom_right, stride * 2, position);
}

bool IsBalancedPowerOfTwo(size_t n, size_t n_left, size_t n_right)
{
  return n >= 2 && (n & (n - 1)) == 0 &&
         n_left == n / 2 && n_right == n / 2;
}

size_t WriteLevelOrderControls(const PackedControls &source,
                               PackedControls *destination,
                               size_t n,
                               size_t root_half,
                               size_t depth,
                               size_t stride,
                               size_t residue,
                               size_t position)
{
  const size_t gate_count = n / 2;
  const size_t stage_start = depth * root_half;
  for (size_t gate = 0; gate < gate_count; ++gate)
    (*destination)[stage_start + gate * stride + residue] =
        source[position + gate];
  position += gate_count;
  if (n == 2)
    return position;

  position = WriteLevelOrderControls(source, destination, n / 2,
                                     root_half, depth + 1, stride * 2,
                                     residue, position);
  return WriteLevelOrderControls(source, destination, n / 2,
                                 root_half, depth + 1, stride * 2,
                                 residue + stride, position);
}

// A DFS control node is identified by its public stride and residue. Record
// its first gate once; a gate at block k is then at start[stride + residue] + k.
size_t BuildDfsControlStarts(size_t length,
                             size_t stride,
                             size_t residue,
                             size_t position,
                             std::vector<size_t> *starts)
{
  (*starts)[stride + residue] = position;
  position += length / 2;
  if (length > 2)
  {
    position = BuildDfsControlStarts(length / 2, stride * 2, residue,
                                     position, starts);
    position = BuildDfsControlStarts(length / 2, stride * 2,
                                     residue + stride, position, starts);
  }
  return position;
}

// Emit the contiguous-block postorder directly from the DFS tape. The public
// gate geometry determines every source position, so no level-order tape is
// materialized.
size_t WritePostOrderFromDfs(PackedControlView source,
                             const std::vector<size_t> &starts,
                             PackedControls *destination,
                             size_t base,
                             size_t length,
                             size_t position)
{
  const size_t half = length / 2;
  if (length > 2)
  {
    position = WritePostOrderFromDfs(source, starts, destination, base,
                                     half, position);
    position = WritePostOrderFromDfs(source, starts, destination, base + half,
                                     half, position);
  }
  const size_t block = base / length;
  for (size_t offset = 0; offset < half; ++offset)
    (*destination)[position + offset] = source[starts[half + offset] + block];
  return position + half;
}

struct GenericGate
{
  void operator()(unsigned char *first,
                  unsigned char *second,
                  size_t block_size,
                  uint8_t control) const
  {
    detail::ApplyOFork(first, second, block_size, control);
  }
};

template <typename Gate>
void ApplyContiguousGateRun(unsigned char *first, unsigned char *second,
                            size_t block_size, size_t count,
                            PackedControlCursor &cursor, const Gate &apply_gate)
{
  size_t gate = 0;
  for (; count - gate >= 4; gate += 4)
  {
    const uint8_t controls = cursor.nextFourUnchecked();
    apply_gate(first, second, block_size, static_cast<uint8_t>(controls & 3U));
    apply_gate(first + block_size, second + block_size, block_size,
               static_cast<uint8_t>((controls >> 2U) & 3U));
    apply_gate(first + 2 * block_size, second + 2 * block_size, block_size,
               static_cast<uint8_t>((controls >> 4U) & 3U));
    apply_gate(first + 3 * block_size, second + 3 * block_size, block_size,
               static_cast<uint8_t>(controls >> 6U));
    first += 4 * block_size;
    second += 4 * block_size;
  }
  for (; gate < count; ++gate)
  {
    apply_gate(first, second, block_size, cursor.nextUnchecked());
    first += block_size;
    second += block_size;
  }
}

template <typename Gate>
void ApplyLevelOrderedGates(unsigned char *data,
                            PackedControlView controls,
                            size_t n,
                            size_t block_size,
                            const Gate &apply_gate)
{
  PackedControlCursor cursor(controls);
  for (size_t stride = 1; stride < n; stride *= 2)
  {
    for (size_t base = 0; base < n; base += stride * 2)
    {
      unsigned char *first = data + base * block_size;
      unsigned char *second = first + stride * block_size;
      ApplyContiguousGateRun(first, second, block_size, stride, cursor, apply_gate);
    }
  }
}

template <typename Gate>
size_t ApplyPostOrderGates(unsigned char *data,
                           PackedControlCursor &cursor,
                           size_t n,
                           size_t block_size,
                           size_t position,
                           const Gate &apply_gate)
{
  const size_t half = n / 2;
  if (n > 2)
  {
    position = ApplyPostOrderGates(data, cursor, half, block_size,
                                   position, apply_gate);
    position = ApplyPostOrderGates(data + half * block_size, cursor,
                                   half, block_size, position, apply_gate);
  }
  ApplyContiguousGateRun(data, data + half * block_size,
                         block_size, half, cursor, apply_gate);
  return cursor.position();
}

#ifndef BEFTS_MODE
template <OFork_Style style>
struct StyledGate
{
  void operator()(unsigned char *first,
                  unsigned char *second,
                  size_t block_size,
                  uint8_t control) const
  {
    ofork_buffer<style>(first, second, static_cast<uint32_t>(block_size),
                        static_cast<uint8_t>((control >> 1U) & 1U),
                        static_cast<uint8_t>(control & 1U));
  }
};

// Keep the hot loop equivalent to the original OFork implementation: choose
// the assembly specialization once and decode the packed tape sequentially.
template <OFork_Style style>
void ApplyLevelOrderedWithStyle(unsigned char *data,
                                PackedControlView controls,
                                size_t n,
                                size_t block_size)
{
  ApplyLevelOrderedGates(data, controls, n, block_size, StyledGate<style>());
}
#endif

} // namespace

std::array<uint8_t, 10> OFRPairMask(uint8_t x, uint8_t y)
{
  const uint8_t x_zero = CtEqualU8(x, OFR_TAG_ZERO);
  const uint8_t x_left = CtEqualU8(x, OFR_TAG_LEFT);
  const uint8_t x_right = CtEqualU8(x, OFR_TAG_RIGHT);
  const uint8_t x_both = CtEqualU8(x, OFR_TAG_BOTH);
  const uint8_t y_zero = CtEqualU8(y, OFR_TAG_ZERO);
  const uint8_t y_left = CtEqualU8(y, OFR_TAG_LEFT);
  const uint8_t y_right = CtEqualU8(y, OFR_TAG_RIGHT);
  const uint8_t y_both = CtEqualU8(y, OFR_TAG_BOTH);

  std::array<uint8_t, 10> pair = {{
      static_cast<uint8_t>(x_zero & y_zero),
      static_cast<uint8_t>((x_zero & y_left) | (x_left & y_zero)),
      static_cast<uint8_t>((x_zero & y_right) | (x_right & y_zero)),
      static_cast<uint8_t>((x_zero & y_both) | (x_both & y_zero)),
      static_cast<uint8_t>(x_left & y_left),
      static_cast<uint8_t>((x_left & y_right) | (x_right & y_left)),
      static_cast<uint8_t>((x_left & y_both) | (x_both & y_left)),
      static_cast<uint8_t>(x_right & y_right),
      static_cast<uint8_t>((x_right & y_both) | (x_both & y_right)),
      static_cast<uint8_t>(x_both & y_both)}};
  return pair;
}

uint8_t OForkControl(uint8_t x,
                     uint8_t y,
                     uint8_t top_tag,
                     uint8_t bottom_tag)
{
  if (((x | y | top_tag | bottom_tag) >> 2U) != 0)
    throw std::invalid_argument("Invalid OFork routing tag");

  const uint8_t straight = static_cast<uint8_t>(
      CtEqualU8(top_tag, x) & CtEqualU8(bottom_tag, y));
  const uint8_t cross = static_cast<uint8_t>(
      CtEqualU8(top_tag, y) & CtEqualU8(bottom_tag, x));
  const uint8_t copy_x = static_cast<uint8_t>(
      CtEqualU8(x, OFR_TAG_BOTH) & CtEqualU8(y, OFR_TAG_ZERO));
  const uint8_t copy_y = static_cast<uint8_t>(
      CtEqualU8(x, OFR_TAG_ZERO) & CtEqualU8(y, OFR_TAG_BOTH));
  const uint8_t copy_pair = static_cast<uint8_t>(copy_x | copy_y);
  const uint8_t left_right = static_cast<uint8_t>(
      CtEqualU8(top_tag, OFR_TAG_LEFT) &
      CtEqualU8(bottom_tag, OFR_TAG_RIGHT));
  const uint8_t right_left = static_cast<uint8_t>(
      CtEqualU8(top_tag, OFR_TAG_RIGHT) &
      CtEqualU8(bottom_tag, OFR_TAG_LEFT));
  const uint8_t fork = static_cast<uint8_t>(
      copy_pair & (left_right | right_left));

  const uint8_t use_cross = static_cast<uint8_t>(cross & (straight ^ 1U));
  const uint8_t use_fork = static_cast<uint8_t>(
      fork & (straight ^ 1U) & (cross ^ 1U));
  const uint8_t fork_control = static_cast<uint8_t>((copy_y << 1U) | copy_y);

  uint8_t control = OFR_STRAIGHT;
  control = CtSelectU8(control, OFR_SWAP, use_cross);
  control = CtSelectU8(control, fork_control, use_fork);
  return control;
}

void OFRNormalizeInPlace(std::vector<uint8_t> &tags,
                                  size_t n,
                                  size_t n_left,
                                  size_t n_right)
{
  ValidateCapacities(n, n_left, n_right);
  if (tags.size() != n)
    throw std::invalid_argument("OFR tag array length mismatch");

  size_t left_weight = 0;
  size_t right_weight = 0;
  uint8_t invalid = 0;
  for (size_t i = 0; i < n; ++i)
  {
    invalid = static_cast<uint8_t>(invalid | (tags[i] >> 2U));
    left_weight += LeftBit(tags[i]);
    right_weight += RightBit(tags[i]);
  }
  if (invalid != 0 || left_weight > n_left || right_weight > n_right)
    throw std::invalid_argument("OFR routing tags do not match output capacities");

  detail::OFRNormalizeOwnedInPlace(tags, n, n_left, n_right, left_weight, right_weight);
}

void detail::OFRNormalizeOwnedInPlace(std::vector<uint8_t> &tags,
                                      size_t n, size_t n_left, size_t n_right,
                                      size_t left_weight, size_t right_weight)
{
  ValidateCapacities(n, n_left, n_right);
  if (tags.size() != n || left_weight > n_left || right_weight > n_right)
    throw std::invalid_argument("OFR owned labels do not match capacities");
  const size_t assign_left = n_left - left_weight;
  const size_t assign_right = n_right - right_weight;
  size_t zero_rank = 0;
  for (size_t i = 0; i < n; ++i)
  {
    const uint8_t is_zero = CtEqualU8(tags[i], OFR_TAG_ZERO);
    const uint8_t use_left = static_cast<uint8_t>(
        is_zero & CtLessSize(zero_rank, assign_left));
    const uint8_t after_left = static_cast<uint8_t>(
        CtLessSize(zero_rank, assign_left) ^ 1U);
    const uint8_t before_end = CtLessSize(
        zero_rank, assign_left + assign_right);
    const uint8_t use_right = static_cast<uint8_t>(
        is_zero & after_left & before_end);

    uint8_t tag = tags[i];
    tag = CtSelectU8(tag, OFR_TAG_LEFT, use_left);
    tag = CtSelectU8(tag, OFR_TAG_RIGHT, use_right);
    tags[i] = tag;
    zero_rank += is_zero;
  }

}

std::vector<uint8_t> OFRNormalize(const std::vector<uint8_t> &tags,
                                  size_t n, size_t n_left, size_t n_right)
{
  std::vector<uint8_t> normalized(tags);
  OFRNormalizeInPlace(normalized, n, n_left, n_right);
  return normalized;
}

namespace
{

// Bits 0..1 are the fixed right/left responsibilities, bits 2..3 the
// variable right/left responsibilities, and bit 4 the diagonal (01,10).
uint8_t ClassifyPairBits(uint8_t x, uint8_t y)
{
  const uint8_t different = static_cast<uint8_t>(x ^ y);
  const uint8_t opposite = static_cast<uint8_t>(
      LeftBit(different) & RightBit(different));
  const uint8_t x_singleton = static_cast<uint8_t>(LeftBit(x) ^ RightBit(x));
  const uint8_t diagonal = static_cast<uint8_t>(opposite & x_singleton);
  const uint8_t variable = static_cast<uint8_t>(
      different & static_cast<uint8_t>(0U - (diagonal ^ 1U)));
  return static_cast<uint8_t>(
      (x & y) | (variable << 2U) | (diagonal << 4U));
}

uint8_t GateControlForBalancedPair(uint8_t x, uint8_t y,
                                   uint8_t top_tag)
{
  // The total responsibility bits are conserved, so once the top tag matches
  // one input, the bottom tag must match the other. The (00,11) pair can also
  // split into (10,01), in which case both lanes copy the 11 input.
  // Testing straight first preserves the canonical encoding for x == y.
  const uint8_t straight = CtEqualU8(top_tag, x);
  const uint8_t cross = static_cast<uint8_t>(
      CtEqualU8(top_tag, y) & (straight ^ 1U));
  // A top tag distinct from both inputs is possible only when (00,11)
  // splits into (10,01). The 11 input is y exactly when its left bit is set.
  const uint8_t fork_y = static_cast<uint8_t>(
      LeftBit(y) & (straight ^ 1U) & (cross ^ 1U));
  const uint8_t top_from_y = static_cast<uint8_t>(cross | fork_y);
  const uint8_t bottom_from_y = static_cast<uint8_t>(straight | fork_y);
  return static_cast<uint8_t>((top_from_y << 1U) | bottom_from_y);
}

inline void RouteMembershipGate(size_t *first, size_t *second,
                                 size_t words_per_row, uint8_t control)
{
  const size_t top_mask = size_t(0) - size_t((control >> 1U) & 1U);
  const size_t bottom_mask = size_t(0) - size_t(control & 1U);
  for (size_t word = 0; word < words_per_row; ++word)
  {
    const size_t x = first[word];
    const size_t y = second[word];
    first[word] = (x & ~top_mask) | (y & top_mask);
    second[word] = (x & ~bottom_mask) | (y & bottom_mask);
  }
}

template <bool PostOrder, bool RouteWords = false>
size_t OFRBalanceLayer(uint8_t *tags, PackedControls &controls,
                       uint8_t *scratch, const size_t *postorder_starts,
                       size_t root_n, size_t base, size_t stride, size_t n,
                       size_t n_left, size_t n_right, size_t position,
                       size_t *rows = NULL, size_t words_per_row = 0)
{
  const size_t gate_count = n / 2;
  uint8_t *features = scratch;
  const size_t node_base = PostOrder ? root_n / (2 * stride) : 0;

  size_t diagonal_count = 0, fixed_left_count = 0;
  size_t fixed_right_count = 0;
  for (size_t gate = 0; gate < gate_count; ++gate)
  {
    const size_t first = base + (2 * gate) * stride;
    const uint8_t pair = ClassifyPairBits(
        tags[first], tags[first + stride]);
    diagonal_count += (pair >> 4U) & 1U;
    fixed_left_count += (pair >> 1U) & 1U;
    fixed_right_count += pair & 1U;
    // Five-bit classification features are scratch, separate from the
    // two-bit output tape; all recursive layers reuse this root allocation.
    features[gate] = pair;
  }

  const int64_t diagonal = static_cast<int64_t>(diagonal_count);
  const int64_t fixed_left = static_cast<int64_t>(fixed_left_count);
  const int64_t fixed_right = static_cast<int64_t>(fixed_right_count);
  int64_t quota_diagonal = 0;
  int64_t quota_left = 0;
  int64_t quota_right = 0;
  if ((n & 3U) == 0 && n_left == gate_count &&
      n_right == gate_count)
  {
    // With balanced capacities, each side has n/2 total bits. Consequently
    // 2*fixed_side + diagonal <= n/2, so floor(diagonal/2) satisfies both
    // quota bounds. This public network shape needs no min/max clipping.
    const int64_t target = static_cast<int64_t>(n / 4);
    quota_diagonal = diagonal / 2;
    quota_left = target - fixed_left - quota_diagonal;
    quota_right = target - fixed_right - diagonal + quota_diagonal;
  }
  else
  {
    const CapacitySplit split = SplitCapacities(n, n_left, n_right);
    const size_t last = base + (n - 1) * stride;
    const int64_t e_left = (n & 1U) != 0 ? LeftBit(tags[last]) : 0;
    const int64_t e_right = (n & 1U) != 0 ? RightBit(tags[last]) : 0;
    const int64_t target_left = static_cast<int64_t>(split.top_left) - e_left;
    const int64_t target_right = static_cast<int64_t>(split.top_right) - e_right;
    // Each fixed pair contributes two responsibility bits and each diagonal
    // or variable pair contributes one. The exact capacities supply totals.
    const int64_t variable_left = static_cast<int64_t>(n_left) - e_left -
                                  2 * fixed_left - diagonal;
    const int64_t variable_right = static_cast<int64_t>(n_right) - e_right -
                                   2 * fixed_right - diagonal;

    int64_t quota_diagonal_min = CtMaxI64(
        0, target_left - fixed_left - variable_left);
    quota_diagonal_min = CtMaxI64(
        quota_diagonal_min, fixed_right + diagonal - target_right);
    int64_t quota_diagonal_max = CtMinI64(
        diagonal, target_left - fixed_left);
    quota_diagonal_max = CtMinI64(
        quota_diagonal_max,
        fixed_right + diagonal + variable_right - target_right);
    quota_diagonal = CtMinI64(
        quota_diagonal_max,
        CtMaxI64(quota_diagonal_min, diagonal / 2));
    quota_left = target_left - fixed_left - quota_diagonal;
    quota_right = target_right - fixed_right - diagonal + quota_diagonal;
  }

  size_t rank_diagonal = 0;
  size_t rank_left = 0;
  size_t rank_right = 0;

  for (size_t gate = 0; gate < gate_count; ++gate)
  {
    const size_t first = base + (2 * gate) * stride;
    const uint8_t x = tags[first];
    const uint8_t y = tags[first + stride];
    const uint8_t pair = features[gate];
    const uint8_t diagonal_type = static_cast<uint8_t>((pair >> 4U) & 1U);
    const uint8_t left_variable_type = static_cast<uint8_t>((pair >> 3U) & 1U);
    const uint8_t right_variable_type = static_cast<uint8_t>((pair >> 2U) & 1U);

    const uint8_t use_diagonal = static_cast<uint8_t>(
        diagonal_type & CtLessSize(
            rank_diagonal, static_cast<size_t>(quota_diagonal)));
    const uint8_t use_left = static_cast<uint8_t>(
        left_variable_type & CtLessSize(
            rank_left, static_cast<size_t>(quota_left)));
    const uint8_t use_right = static_cast<uint8_t>(
        right_variable_type & CtLessSize(
            rank_right, static_cast<size_t>(quota_right)));
    const uint8_t top_left_fixed = static_cast<uint8_t>((pair >> 1U) & 1U);
    const uint8_t top_right_fixed = static_cast<uint8_t>(pair & 1U);
    const uint8_t top_left = static_cast<uint8_t>(
        top_left_fixed | use_diagonal | use_left);
    const uint8_t top_right = static_cast<uint8_t>(
        top_right_fixed |
        (diagonal_type & (use_diagonal ^ 1U)) |
        use_right);
    const uint8_t top_tag = static_cast<uint8_t>(
        (top_left << 1U) | top_right);
    // For each responsibility bit, bottom = x + y - top equals x ^ y ^ top
    // because the conserved sum is 0, 1, or 2 and top is one bit.
    const uint8_t bottom_tag = static_cast<uint8_t>(x ^ y ^ top_tag);

    const uint8_t control = GateControlForBalancedPair(x, y, top_tag);
    if (PostOrder)
      controls[postorder_starts[node_base + gate] + base] = control;
    else
      controls[position + gate] = control;
    if (RouteWords)
      RouteMembershipGate(rows + first * words_per_row,
                           rows + (first + stride) * words_per_row,
                           words_per_row, control);
    tags[first] = top_tag;
    tags[first + stride] = bottom_tag;
    rank_diagonal += diagonal_type;
    rank_left += left_variable_type;
    rank_right += right_variable_type;
  }

  return position + gate_count;
}

size_t OFRBalanceInPlaceImpl(uint8_t *tags, PackedControls &controls, uint8_t *scratch,
                             size_t base, size_t stride, size_t n,
                             size_t n_left, size_t n_right, size_t position)
{
  return OFRBalanceLayer<false>(tags, controls, scratch, NULL, 0,
                                base, stride, n, n_left, n_right, position);
}

size_t OFRControlWriteAndRouteImpl(
    uint8_t *tags, PackedControls &controls, uint8_t *scratch,
    size_t *rows, size_t words_per_row,
    size_t base, size_t stride, size_t n,
    size_t n_left, size_t n_right, size_t position)
{
  if (n_left == 0 || n_right == 0)
    return position;
  if (n == 2)
  {
    const uint8_t control = static_cast<uint8_t>(OFR_TAG_BOTH ^ tags[base]);
    controls[position] = control;
    RouteMembershipGate(rows + base * words_per_row,
                         rows + (base + stride) * words_per_row,
                         words_per_row, control);
    tags[base] = OFR_TAG_LEFT;
    tags[base + stride] = OFR_TAG_RIGHT;
    return position + 1;
  }

  position = OFRBalanceLayer<false, true>(
      tags, controls, scratch, NULL, 0, base, stride, n,
      n_left, n_right, position, rows, words_per_row);
  const CapacitySplit split = SplitCapacities(n, n_left, n_right);
  position = OFRControlWriteAndRouteImpl(
      tags, controls, scratch, rows, words_per_row, base, stride * 2,
      split.n_top, split.top_left, split.top_right, position);
  return OFRControlWriteAndRouteImpl(
      tags, controls, scratch, rows, words_per_row, base + stride, stride * 2,
      split.n_bottom, split.bottom_left, split.bottom_right, position);
}

struct ResidueBalanceState
{
  size_t diagonal, fixed_left, fixed_right;
  size_t quota_diagonal, quota_left, quota_right;
  size_t rank_diagonal, rank_left, rank_right;
};

// Private SSE2 types avoid host intrinsic headers: SGX builds use -nostdinc.
typedef int OfRVec32 __attribute__((vector_size(16)));
typedef short OfRVec16 __attribute__((vector_size(16)));
typedef char OfRVec8 __attribute__((vector_size(16)));

inline OfRVec32 LoadVec32(const void *source)
{
  OfRVec32 result;
  std::memcpy(&result, source, sizeof(result));
  return result;
}

inline void StoreVec32(void *destination, OfRVec32 value)
{
  std::memcpy(destination, &value, sizeof(value));
}

inline OfRVec32 TagLanes4(const uint8_t *tags)
{
  const OfRVec8 zero8 = {};
  const OfRVec16 zero16 = {};
  OfRVec8 bytes = {};
  std::memcpy(&bytes, tags, 4);
  const OfRVec16 words = (OfRVec16)__builtin_ia32_punpcklbw128(bytes, zero8);
  return (OfRVec32)__builtin_ia32_punpcklwd128(words, zero16);
}

inline uint32_t PackTagLanes4(OfRVec32 lanes)
{
  const OfRVec32 zero32 = {};
  const OfRVec16 zero16 = {};
  const OfRVec16 words = __builtin_ia32_packssdw128(lanes, zero32);
  const OfRVec8 bytes = __builtin_ia32_packuswb128(words, zero16);
  uint32_t result;
  std::memcpy(&result, &bytes, sizeof(result));
  return result;
}

inline OfRVec32 PairLanes4(OfRVec32 x, OfRVec32 y)
{
  const OfRVec32 one = {1, 1, 1, 1};
  const OfRVec32 different = x ^ y;
  const OfRVec32 diagonal = ((different >> 1) & different) &
                           ((x >> 1) ^ x) & one;
  const OfRVec32 variable = different & (diagonal - one);
  return (x & y) | (variable << 2) | (diagonal << 4);
}

struct alignas(16) ResidueBalance32
{
  uint32_t diagonal[256], fixed_left[256], fixed_right[256];
  uint32_t quota_diagonal[256], quota_left[256], quota_right[256];
  uint32_t rank_diagonal[256], rank_left[256], rank_right[256];
};

template <bool RouteWords, bool OneWord>
void OFRPostOrderTile32(uint8_t *tags, PackedControlMutableView controls,
                       size_t *rows, size_t words_per_row, size_t stride,
                       size_t depth, size_t length, size_t residue, size_t tile)
{
  const OfRVec32 zero = {};
  const OfRVec32 one = {1, 1, 1, 1};
  const OfRVec32 two = {2, 2, 2, 2};
  const OfRVec32 three = {3, 3, 3, 3};
  ResidueBalance32 states;
  const size_t gate_count = length / 2;
  if (length > 2)
  {
    std::fill(states.diagonal, states.diagonal + tile, 0);
    std::fill(states.fixed_left, states.fixed_left + tile, 0);
    std::fill(states.fixed_right, states.fixed_right + tile, 0);
    for (size_t gate = 0; gate < gate_count; ++gate)
    {
      const size_t first = 2 * gate * stride + residue;
      for (size_t r = 0; r < tile; r += 4)
      {
        const OfRVec32 pair = PairLanes4(
            TagLanes4(tags + first + r), TagLanes4(tags + first + stride + r));
        StoreVec32(states.diagonal + r,
                    LoadVec32(states.diagonal + r) + ((pair >> 4) & one));
        StoreVec32(states.fixed_left + r,
                    LoadVec32(states.fixed_left + r) + ((pair >> 1) & one));
        StoreVec32(states.fixed_right + r,
                    LoadVec32(states.fixed_right + r) + (pair & one));
      }
    }
    const int target = static_cast<int>(length / 4);
    const OfRVec32 targets = {target, target, target, target};
    for (size_t r = 0; r < tile; r += 4)
    {
      const OfRVec32 diagonal = LoadVec32(states.diagonal + r);
      const OfRVec32 quota_diagonal = diagonal >> 1;
      StoreVec32(states.quota_diagonal + r, quota_diagonal);
      StoreVec32(states.quota_left + r,
                  targets - LoadVec32(states.fixed_left + r) - quota_diagonal);
      StoreVec32(states.quota_right + r,
                  targets - LoadVec32(states.fixed_right + r) -
                  (diagonal - quota_diagonal));
    }
  }

  for (size_t r = 0; r < tile; r += 4)
  {
    OfRVec32 remaining_diagonal = length > 2 ? LoadVec32(states.quota_diagonal + r) : zero;
    OfRVec32 remaining_left = length > 2 ? LoadVec32(states.quota_left + r) : zero;
    OfRVec32 remaining_right = length > 2 ? LoadVec32(states.quota_right + r) : zero;
    size_t layer_start = stride * depth;
    for (size_t gate = 0; gate < gate_count; ++gate)
    {
      const size_t first = 2 * gate * stride + residue;
      const OfRVec32 x = TagLanes4(tags + first + r);
      const OfRVec32 y = TagLanes4(tags + first + stride + r);
      OfRVec32 top_tag = two;
      OfRVec32 bottom_tag = one;
      OfRVec32 control;
      if (length == 2)
        control = three ^ x;
      else
      {
        const OfRVec32 pair = PairLanes4(x, y);
        const OfRVec32 diagonal = (pair >> 4) & one;
        const OfRVec32 left_type = (pair >> 3) & one;
        const OfRVec32 right_type = (pair >> 2) & one;
        const OfRVec32 use_diagonal = diagonal &
            (remaining_diagonal > zero);
        const OfRVec32 use_left = left_type &
            (remaining_left > zero);
        const OfRVec32 use_right = right_type &
            (remaining_right > zero);
        const OfRVec32 top_left = ((pair >> 1) & one) | use_diagonal | use_left;
        const OfRVec32 top_right = (pair & one) |
                                   (diagonal & (use_diagonal ^ one)) | use_right;
        top_tag = (top_left << 1) | top_right;
        bottom_tag = x ^ y ^ top_tag;
        const OfRVec32 straight = top_tag == x;
        const OfRVec32 cross = (top_tag == y) & ~straight;
        const OfRVec32 fork_y = (y >> 1) & one & ~(straight | cross);
        control = (((cross & one) | fork_y) << 1) | (straight & one) | fork_y;
        remaining_diagonal -= diagonal;
        remaining_left -= left_type;
        remaining_right -= right_type;
      }

      const uint32_t gate_bytes = PackTagLanes4(control);
      const uint8_t encoded = static_cast<uint8_t>(
          gate_bytes | (gate_bytes >> 6U) | (gate_bytes >> 12U) | (gate_bytes >> 18U));
      controls.set_four_encoded(layer_start + residue + r, encoded);
      if (RouteWords)
      {
        if (OneWord)
        {
          const OfRVec32 top_masks = zero - ((control >> 1) & one);
          const OfRVec32 bottom_masks = zero - (control & one);
          for (size_t half = 0; half < 2; ++half)
          {
            const OfRVec32 top_mask = half == 0
                ? __builtin_ia32_punpckldq128(top_masks, top_masks)
                : __builtin_ia32_punpckhdq128(top_masks, top_masks);
            const OfRVec32 bottom_mask = half == 0
                ? __builtin_ia32_punpckldq128(bottom_masks, bottom_masks)
                : __builtin_ia32_punpckhdq128(bottom_masks, bottom_masks);
            size_t *a = rows + first + r + 2 * half;
            size_t *b = a + stride;
            const OfRVec32 row_x = LoadVec32(a);
            const OfRVec32 row_y = LoadVec32(b);
            const OfRVec32 different = row_x ^ row_y;
            StoreVec32(a, row_x ^ (different & top_mask));
            StoreVec32(b, row_x ^ (different & bottom_mask));
          }
        }
        else
        {
          alignas(16) uint32_t gate_controls[4];
          StoreVec32(gate_controls, control);
          for (size_t lane = 0; lane < 4; ++lane)
            RouteMembershipGate(rows + (first + r + lane) * words_per_row,
                                 rows + (first + stride + r + lane) * words_per_row,
                                 words_per_row, static_cast<uint8_t>(gate_controls[lane]));
        }
      }
      const uint32_t top_bytes = PackTagLanes4(top_tag);
      const uint32_t bottom_bytes = PackTagLanes4(bottom_tag);
      std::memcpy(tags + first + r, &top_bytes, 4);
      std::memcpy(tags + first + stride + r, &bottom_bytes, 4);
    if (gate + 1 < gate_count)
    {
      const size_t carry = static_cast<size_t>(__builtin_ctzll(
          static_cast<unsigned long long>(gate + 1)));
      layer_start += stride * (depth + 1 + (size_t(2) << carry) - 2);
    }
    }
  }
}


inline OfRVec16 LoadVec16(const void *source)
{
  OfRVec16 result;
  std::memcpy(&result, source, sizeof(result));
  return result;
}

inline void StoreVec16(void *destination, OfRVec16 value)
{
  std::memcpy(destination, &value, sizeof(value));
}

inline OfRVec16 TagLanes8(const uint8_t *tags)
{
  const OfRVec8 zero = {};
  OfRVec8 bytes = {};
  std::memcpy(&bytes, tags, 8);
  return (OfRVec16)__builtin_ia32_punpcklbw128(bytes, zero);
}

inline uint64_t PackTagLanes8(OfRVec16 lanes)
{
  const OfRVec16 zero = {};
  const OfRVec8 bytes = __builtin_ia32_packuswb128(lanes, zero);
  uint64_t result;
  std::memcpy(&result, &bytes, sizeof(result));
  return result;
}

inline uint16_t PackControlLanes8(OfRVec16 controls)
{
  const OfRVec16 weights = {1, 4, 16, 64, 1, 4, 16, 64};
  const OfRVec32 pairs = __builtin_ia32_pmaddwd128(controls, weights);
  const OfRVec32 combined = pairs + __builtin_ia32_pshufd(pairs, 0xb1);
  const uint32_t bytes = PackTagLanes4(combined);
  return static_cast<uint16_t>((bytes & 255U) | ((bytes >> 8U) & 65280U));
}

inline OfRVec16 PairLanes8(OfRVec16 x, OfRVec16 y)
{
  const OfRVec16 one = {1, 1, 1, 1, 1, 1, 1, 1};
  const OfRVec16 different = x ^ y;
  const OfRVec16 diagonal = ((different >> 1) & different) &
                           ((x >> 1) ^ x) & one;
  const OfRVec16 variable = different & (diagonal - one);
  return (x & y) | (variable << 2) | (diagonal << 4);
}

struct alignas(16) ResidueBalance16
{
  uint16_t diagonal[256], fixed_left[256], fixed_right[256];
  uint16_t quota_diagonal[256], quota_left[256], quota_right[256];
  uint16_t rank_diagonal[256], rank_left[256], rank_right[256];
};

template <bool RouteWords, bool OneWord>
void OFRPostOrderTile16(uint8_t *tags, PackedControlMutableView controls,
                       size_t *rows, size_t words_per_row, size_t stride,
                       size_t depth, size_t length, size_t residue, size_t tile)
{
  const OfRVec16 zero = {};
  const OfRVec16 one = {1, 1, 1, 1, 1, 1, 1, 1};
  const OfRVec16 two = {2, 2, 2, 2, 2, 2, 2, 2};
  const OfRVec16 three = {3, 3, 3, 3, 3, 3, 3, 3};
  ResidueBalance16 states;
  const size_t gate_count = length / 2;
  if (length > 2)
  {
    std::fill(states.diagonal, states.diagonal + tile, 0);
    std::fill(states.fixed_left, states.fixed_left + tile, 0);
    std::fill(states.fixed_right, states.fixed_right + tile, 0);
    for (size_t gate = 0; gate < gate_count; ++gate)
    {
      const size_t first = 2 * gate * stride + residue;
      for (size_t r = 0; r < tile; r += 8)
      {
        const OfRVec16 pair = PairLanes8(
            TagLanes8(tags + first + r), TagLanes8(tags + first + stride + r));
        StoreVec16(states.diagonal + r,
                    LoadVec16(states.diagonal + r) + ((pair >> 4) & one));
        StoreVec16(states.fixed_left + r,
                    LoadVec16(states.fixed_left + r) + ((pair >> 1) & one));
        StoreVec16(states.fixed_right + r,
                    LoadVec16(states.fixed_right + r) + (pair & one));
      }
    }
    const short target = static_cast<short>(length / 4);
    const OfRVec16 targets = {target, target, target, target, target, target, target, target};
    for (size_t r = 0; r < tile; r += 8)
    {
      const OfRVec16 diagonal = LoadVec16(states.diagonal + r);
      const OfRVec16 quota_diagonal = diagonal >> 1;
      StoreVec16(states.quota_diagonal + r, quota_diagonal);
      StoreVec16(states.quota_left + r,
                  targets - LoadVec16(states.fixed_left + r) - quota_diagonal);
      StoreVec16(states.quota_right + r,
                  targets - LoadVec16(states.fixed_right + r) -
                  (diagonal - quota_diagonal));
    }
  }

  for (size_t r = 0; r < tile; r += 8)
  {
    OfRVec16 remaining_diagonal = length > 2 ? LoadVec16(states.quota_diagonal + r) : zero;
    OfRVec16 remaining_left = length > 2 ? LoadVec16(states.quota_left + r) : zero;
    OfRVec16 remaining_right = length > 2 ? LoadVec16(states.quota_right + r) : zero;
    size_t layer_start = stride * depth;
    for (size_t gate = 0; gate < gate_count; ++gate)
    {
      const size_t first = 2 * gate * stride + residue;
      const OfRVec16 x = TagLanes8(tags + first + r);
      const OfRVec16 y = TagLanes8(tags + first + stride + r);
      OfRVec16 top_tag = two;
      OfRVec16 bottom_tag = one;
      OfRVec16 control;
      if (length == 2)
        control = three ^ x;
      else
      {
        const OfRVec16 pair = PairLanes8(x, y);
        const OfRVec16 diagonal = (pair >> 4) & one;
        const OfRVec16 left_type = (pair >> 3) & one;
        const OfRVec16 right_type = (pair >> 2) & one;
        const OfRVec16 use_diagonal = diagonal &
            (remaining_diagonal > zero);
        const OfRVec16 use_left = left_type &
            (remaining_left > zero);
        const OfRVec16 use_right = right_type &
            (remaining_right > zero);
        const OfRVec16 top_left = ((pair >> 1) & one) | use_diagonal | use_left;
        const OfRVec16 top_right = (pair & one) |
                                   (diagonal & (use_diagonal ^ one)) | use_right;
        top_tag = (top_left << 1) | top_right;
        bottom_tag = x ^ y ^ top_tag;
        const OfRVec16 straight = top_tag == x;
        const OfRVec16 cross = (top_tag == y) & ~straight;
        const OfRVec16 fork_y = (y >> 1) & one & ~(straight | cross);
        control = (((cross & one) | fork_y) << 1) | (straight & one) | fork_y;
        remaining_diagonal -= diagonal;
        remaining_left -= left_type;
        remaining_right -= right_type;
      }

      const uint16_t encoded = PackControlLanes8(control);
      controls.set_eight_encoded(layer_start + residue + r, encoded);
      if (RouteWords)
      {
        if (OneWord)
        {
          const OfRVec16 top_masks = zero - ((control >> 1) & one);
          const OfRVec16 bottom_masks = zero - (control & one);
          for (size_t half = 0; half < 4; ++half)
          {
            const OfRVec32 top32 = half < 2
                ? (OfRVec32)__builtin_ia32_punpcklwd128(top_masks, top_masks)
                : (OfRVec32)__builtin_ia32_punpckhwd128(top_masks, top_masks);
            const OfRVec32 bottom32 = half < 2
                ? (OfRVec32)__builtin_ia32_punpcklwd128(bottom_masks, bottom_masks)
                : (OfRVec32)__builtin_ia32_punpckhwd128(bottom_masks, bottom_masks);
            const OfRVec32 top_mask = (half & 1U) == 0
                ? __builtin_ia32_punpckldq128(top32, top32)
                : __builtin_ia32_punpckhdq128(top32, top32);
            const OfRVec32 bottom_mask = (half & 1U) == 0
                ? __builtin_ia32_punpckldq128(bottom32, bottom32)
                : __builtin_ia32_punpckhdq128(bottom32, bottom32);
            size_t *a = rows + first + r + 2 * half;
            size_t *b = a + stride;
            const OfRVec32 row_x = LoadVec32(a);
            const OfRVec32 row_y = LoadVec32(b);
            const OfRVec32 different = row_x ^ row_y;
            StoreVec32(a, row_x ^ (different & top_mask));
            StoreVec32(b, row_x ^ (different & bottom_mask));
          }
        }
        else
        {
          alignas(16) uint16_t gate_controls[8];
          StoreVec16(gate_controls, control);
          for (size_t lane = 0; lane < 8; ++lane)
            RouteMembershipGate(rows + (first + r + lane) * words_per_row,
                                 rows + (first + stride + r + lane) * words_per_row,
                                 words_per_row, static_cast<uint8_t>(gate_controls[lane]));
        }
      }
      const uint64_t top_bytes = PackTagLanes8(top_tag);
      const uint64_t bottom_bytes = PackTagLanes8(bottom_tag);
      std::memcpy(tags + first + r, &top_bytes, 8);
      std::memcpy(tags + first + stride + r, &bottom_bytes, 8);
    if (gate + 1 < gate_count)
    {
      const size_t carry = static_cast<size_t>(__builtin_ctzll(
          static_cast<unsigned long long>(gate + 1)));
      layer_start += stride * (depth + 1 + (size_t(2) << carry) - 2);
    }
    }
  }
}

size_t ResidueTileSize(size_t words_per_row, size_t counter_bytes)
{
  const size_t budget = 24 * 1024;
  // Metadata and the two active tags plus both membership rows must fit the
  // public working-set budget. Very wide rows use a one-residue tile.
  if (words_per_row > budget / (2 * sizeof(size_t)))
    return 1;
  const size_t bytes = 9 * counter_bytes + 2 +
                       2 * words_per_row * sizeof(size_t);
  const size_t limit = std::min<size_t>(256, budget / bytes);
  size_t tile = 1;
  while (tile <= limit / 2)
    tile *= 2;
  return tile;
}

template <bool RouteWords>
void OFRControlPostOrderTiledImpl(uint8_t *tags,
                                 PackedControlMutableView controls,
                                 size_t *rows, size_t words_per_row, size_t n)
{
  std::array<ResidueBalanceState, 256> states;
  size_t depth = 0;
  // At stride s, each residue is an independent DFS view of length n/s.
  // Processing those views by tiles preserves each view's gate/rank order
  // while accessing contiguous tag and membership lanes.
  for (size_t stride = 1; stride < n; stride *= 2, ++depth)
  {
    const auto phase_start = std::chrono::steady_clock::now();
    const size_t length = n / stride;
    const size_t gate_count = length / 2;
    const size_t lane_width = length <= 32768 ? 8 :
        n <= static_cast<size_t>(std::numeric_limits<int32_t>::max()) ? 4 : 1;
    const size_t counter_bytes = lane_width == 8 ? sizeof(uint16_t) :
        lane_width == 4 ? sizeof(uint32_t) : sizeof(size_t);
    size_t max_tile = ResidueTileSize(RouteWords ? words_per_row : 0, counter_bytes);
    if (max_tile < lane_width)
      max_tile = ResidueTileSize(RouteWords ? words_per_row : 0, sizeof(size_t));
    const size_t tile = std::min(stride, max_tile);
    for (size_t residue = 0; residue < stride; residue += tile)
    {
      if (length <= 32768 && tile >= 8)
      {
        if (!RouteWords)
          OFRPostOrderTile16<false, false>(tags, controls, rows, words_per_row,
              stride, depth, length, residue, tile);
        else if (words_per_row == 1)
          OFRPostOrderTile16<true, true>(tags, controls, rows, words_per_row,
              stride, depth, length, residue, tile);
        else
          OFRPostOrderTile16<true, false>(tags, controls, rows, words_per_row,
              stride, depth, length, residue, tile);
        continue;
      }
      // Signed SSE2 comparisons are valid because all ranks/quotas are at
      // most n/2. This choice depends only on public dimensions.
      if (n <= static_cast<size_t>(std::numeric_limits<int32_t>::max()) && tile >= 4)
      {
        if (!RouteWords)
          OFRPostOrderTile32<false, false>(tags, controls, rows, words_per_row,
              stride, depth, length, residue, tile);
        else if (words_per_row == 1)
          OFRPostOrderTile32<true, true>(tags, controls, rows, words_per_row,
              stride, depth, length, residue, tile);
        else
          OFRPostOrderTile32<true, false>(tags, controls, rows, words_per_row,
              stride, depth, length, residue, tile);
        continue;
      }
      if (length > 2)
      {
        for (size_t r = 0; r < tile; ++r)
        {
          ResidueBalanceState &state = states[r];
          state.diagonal = state.fixed_left = state.fixed_right = 0;
          state.rank_diagonal = state.rank_left = state.rank_right = 0;
        }
        for (size_t gate = 0; gate < gate_count; ++gate)
        {
          const size_t first = 2 * gate * stride + residue;
          for (size_t r = 0; r < tile; ++r)
          {
            const uint8_t pair = ClassifyPairBits(
                tags[first + r], tags[first + stride + r]);
            ResidueBalanceState &state = states[r];
            state.diagonal += (pair >> 4U) & 1U;
            state.fixed_left += (pair >> 1U) & 1U;
            state.fixed_right += pair & 1U;
          }
        }
        for (size_t r = 0; r < tile; ++r)
        {
          ResidueBalanceState &state = states[r];
          state.quota_diagonal = state.diagonal / 2;
          state.quota_left = length / 4 - state.fixed_left -
                             state.quota_diagonal;
          state.quota_right = length / 4 - state.fixed_right -
                              (state.diagonal - state.quota_diagonal);
        }
      }

      // This is the postorder layer start for the first contiguous block of
      // width 2*s. Subsequent starts depend on the carry bits of gate+1;
      // neither an n-entry index table nor a second control tape is needed.
      size_t layer_start = stride * depth;
      for (size_t gate = 0; gate < gate_count; ++gate)
      {
        const size_t first = 2 * gate * stride + residue;
        for (size_t r = 0; r < tile; ++r)
        {
          const uint8_t x = tags[first + r];
          const uint8_t y = tags[first + stride + r];
          uint8_t top_tag = OFR_TAG_LEFT;
          uint8_t bottom_tag = OFR_TAG_RIGHT;
          uint8_t control;
          if (length == 2)
            control = static_cast<uint8_t>(OFR_TAG_BOTH ^ x);
          else
          {
            // Reclassify the already-loaded pair rather than writing and
            // rereading a root-sized feature array.
            const uint8_t pair = ClassifyPairBits(x, y);
            const uint8_t diagonal_type = static_cast<uint8_t>((pair >> 4U) & 1U);
            const uint8_t left_type = static_cast<uint8_t>((pair >> 3U) & 1U);
            const uint8_t right_type = static_cast<uint8_t>((pair >> 2U) & 1U);
            ResidueBalanceState &state = states[r];
            const uint8_t use_diagonal = static_cast<uint8_t>(
                diagonal_type & CtLessSize(state.rank_diagonal, state.quota_diagonal));
            const uint8_t use_left = static_cast<uint8_t>(
                left_type & CtLessSize(state.rank_left, state.quota_left));
            const uint8_t use_right = static_cast<uint8_t>(
                right_type & CtLessSize(state.rank_right, state.quota_right));
            const uint8_t top_left = static_cast<uint8_t>(
                ((pair >> 1U) & 1U) | use_diagonal | use_left);
            const uint8_t top_right = static_cast<uint8_t>(
                (pair & 1U) | (diagonal_type & (use_diagonal ^ 1U)) | use_right);
            top_tag = static_cast<uint8_t>((top_left << 1U) | top_right);
            bottom_tag = static_cast<uint8_t>(x ^ y ^ top_tag);
            control = GateControlForBalancedPair(x, y, top_tag);
            state.rank_diagonal += diagonal_type;
            state.rank_left += left_type;
            state.rank_right += right_type;
          }
          controls.set(layer_start + residue + r, control);
          if (RouteWords)
            RouteMembershipGate(rows + (first + r) * words_per_row,
                                 rows + (first + stride + r) * words_per_row,
                                 words_per_row, control);
          tags[first + r] = top_tag;
          tags[first + stride + r] = bottom_tag;
        }
        if (gate + 1 < gate_count)
        {
          const size_t carry = static_cast<size_t>(__builtin_ctzll(
              static_cast<unsigned long long>(gate + 1)));
          layer_start += stride * (depth + 1 + (size_t(2) << carry) - 2);
        }
      }
    }
    const double phase_ms = std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-phase_start).count();
    std::fprintf(stderr,"PHASE,%zu,%zu,%zu,%zu,%d,%.6f\n",n,stride,tile,words_per_row,int(RouteWords),phase_ms);
  }
}

void ValidateTagView(const std::vector<uint8_t> &tags,
                     size_t base, size_t stride, size_t n,
                     size_t n_left, size_t n_right)
{
  ValidateCapacities(n, n_left, n_right);
  if (stride == 0 || base >= tags.size() ||
      n - 1 > (tags.size() - 1 - base) / stride)
    throw std::invalid_argument("Invalid OFR tag view");
  size_t left_weight = 0, right_weight = 0;
  uint8_t invalid = 0;
  for (size_t i = 0; i < n; ++i)
  {
    const uint8_t tag = tags[base + i * stride];
    invalid = static_cast<uint8_t>(invalid | (tag >> 2U));
    left_weight += LeftBit(tag);
    right_weight += RightBit(tag);
  }
  if (invalid != 0 || left_weight != n_left || right_weight != n_right)
    throw std::invalid_argument("OFR tag view capacities mismatch");
}

} // namespace

OFRBalanceResult OFRBalance(const std::vector<uint8_t> &tags,
                            size_t n, size_t n_left, size_t n_right)
{
  ValidateTags(tags, n, n_left, n_right, true);
  if (n < 3)
    throw std::invalid_argument("OFR balance requires at least three tags");
  std::vector<uint8_t> work(tags);
  OFRBalanceResult result;
  result.controls.resize(n / 2);
  std::vector<uint8_t> scratch(n / 2);
  OFRBalanceInPlaceImpl(work.data(), result.controls, scratch.data(), 0, 1, n,
                        n_left, n_right, 0);
  result.top_tags.reserve(n / 2 + n % 2);
  result.bottom_tags.reserve(n / 2);
  for (size_t i = 0; i < n; ++i)
    (i % 2 == 0 ? result.top_tags : result.bottom_tags).push_back(work[i]);
  return result;
}

size_t OFRBalanceInPlace(std::vector<uint8_t> &tags,
                         PackedControls &controls,
                         size_t base, size_t stride, size_t n,
                         size_t n_left, size_t n_right, size_t position)
{
  if (n < 3)
    throw std::invalid_argument("OFR balance requires at least three tags");
  ValidateTagView(tags, base, stride, n, n_left, n_right);
  const size_t required = n / 2;
  if (position > controls.size() || required > controls.size() - position)
    throw std::length_error("OFR balance exceeds control array");
  std::vector<uint8_t> scratch(n / 2);
  return OFRBalanceInPlaceImpl(tags.data(), controls, scratch.data(), base, stride, n,
                               n_left, n_right, position);
}

size_t OFRControlCount(size_t n, size_t n_left, size_t n_right)
{
  ValidateCapacities(n, n_left, n_right);
  return OFRControlCountImpl(n, n_left, n_right);
}

size_t OFRControlWrite(const std::vector<uint8_t> &tags,
                       PackedControls &controls,
                       size_t n,
                       size_t n_left,
                       size_t n_right,
                       size_t position)
{
  ValidateTags(tags, n, n_left, n_right, true);
  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  if (position > controls.size() || required > controls.size() - position)
    throw std::length_error("OFR control write exceeds destination array");
  std::vector<uint8_t> work(tags);
  std::vector<uint8_t> scratch(n / 2);
  return OFRControlWriteImpl(
      work.data(), controls, scratch.data(), 0, 1, n, n_left, n_right, position);
}

size_t OFRControlWrite(std::vector<uint8_t> &tags,
                       PackedControls &controls,
                       size_t base, size_t stride, size_t n,
                       size_t n_left, size_t n_right, size_t position)
{
  ValidateTagView(tags, base, stride, n, n_left, n_right);
  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  if (position > controls.size() || required > controls.size() - position)
    throw std::length_error("OFR control write exceeds destination array");
  std::vector<uint8_t> scratch(n / 2);
  return OFRControlWriteImpl(tags.data(), controls, scratch.data(), base, stride, n,
                             n_left, n_right, position);
}

size_t OFRControlWrite(std::vector<uint8_t> &tags,
                       PackedControls &controls,
                       size_t n, size_t n_left, size_t n_right,
                       size_t position)
{
  return OFRControlWrite(tags, controls, 0, 1, n,
                         n_left, n_right, position);
}

size_t OFRControlWriteAndRoute(std::vector<uint8_t> &tags,
                               PackedControls &controls,
                               size_t *rows, size_t words_per_row,
                               size_t n, size_t n_left, size_t n_right,
                               size_t position)
{
  ValidateTagView(tags, 0, 1, n, n_left, n_right);
  return detail::OFRControlWriteAndRouteNormalized(
      tags, controls, rows, words_per_row, n, n_left, n_right, position,
      OFRControlCountImpl(n, n_left, n_right));
}

size_t detail::OFRControlWriteAndRouteNormalized(
    std::vector<uint8_t> &tags, PackedControls &controls,
    size_t *rows, size_t words_per_row, size_t n,
    size_t n_left, size_t n_right, size_t position, size_t control_count,
    std::vector<uint8_t> *feature_scratch)
{
  ValidateCapacities(n, n_left, n_right);
  size_t row_words = 0;
  if (tags.size() != n || rows == NULL || words_per_row == 0 ||
      MulOverflowSize(n, words_per_row, &row_words))
    throw std::invalid_argument("Invalid OFR membership dimensions");
  (void)row_words;
  if (position > controls.size() || control_count > controls.size() - position)
    throw std::length_error("OFR control write exceeds destination array");
  std::vector<uint8_t> local_scratch;
  std::vector<uint8_t> &scratch = feature_scratch ? *feature_scratch : local_scratch;
  scratch.resize(n / 2);
  const size_t next = OFRControlWriteAndRouteImpl(
      tags.data(), controls, scratch.data(), rows, words_per_row,
      0, 1, n, n_left, n_right, position);
  if (next - position != control_count)
    throw std::logic_error("OFR normalized control count mismatch");
  return next;
}

size_t OFRControlWritePostOrderAndRoute(std::vector<uint8_t> &tags,
                                        PackedControls &controls,
                                        size_t *rows, size_t words_per_row,
                                        size_t n, size_t n_left, size_t n_right,
                                        size_t position)
{
  ValidateTagView(tags, 0, 1, n, n_left, n_right);
  return detail::OFRControlWritePostOrderAndRouteNormalized(
      tags, controls, rows, words_per_row, n, n_left, n_right, position,
      OFRControlCountImpl(n, n_left, n_right));
}

size_t detail::OFRControlWritePostOrderAndRouteNormalized(
    std::vector<uint8_t> &tags, PackedControls &controls,
    size_t *rows, size_t words_per_row, size_t n,
    size_t n_left, size_t n_right, size_t position, size_t control_count)
{
  ValidateCapacities(n, n_left, n_right);
  if (!IsBalancedPowerOfTwo(n, n_left, n_right))
    throw std::invalid_argument("Postorder OFR requires balanced power-of-two capacities");
  size_t row_words = 0;
  if (tags.size() != n || rows == NULL || words_per_row == 0 ||
      MulOverflowSize(n, words_per_row, &row_words))
    throw std::invalid_argument("Invalid OFR membership dimensions");
  (void)row_words;
  if (position > controls.size() || control_count > controls.size() - position)
    throw std::length_error("OFR control write exceeds destination array");
  OFRControlPostOrderTiledImpl<true>(
      tags.data(), controls.mutable_view(position, control_count),
      rows, words_per_row, n);
  return position + control_count;
}

PackedControls OFRControl(const std::vector<uint8_t> &tags,
                                size_t n,
                                size_t n_left,
                                size_t n_right)
{
  std::vector<uint8_t> normalized = OFRNormalize(
      tags, n, n_left, n_right);
  PackedControls controls(
      OFRControlCountImpl(n, n_left, n_right));
  std::vector<uint8_t> scratch(n / 2);
  const size_t next = OFRControlWriteImpl(
      normalized.data(), controls, scratch.data(), 0, 1, n, n_left, n_right, 0);
  if (next != controls.size())
    throw std::logic_error("OFR control write/count mismatch");
  return controls;
}

PackedControls OFRControlPostOrder(const std::vector<uint8_t> &tags,
                                         size_t n,
                                         size_t n_left,
                                         size_t n_right)
{
  ValidateCapacities(n, n_left, n_right);
  if (!IsBalancedPowerOfTwo(n, n_left, n_right))
    throw std::invalid_argument("Postorder OFR requires balanced power-of-two capacities");
  std::vector<uint8_t> normalized = OFRNormalize(
      tags, n, n_left, n_right);
  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  PackedControls controls(required);
  OFRControlPostOrderTiledImpl<false>(
      normalized.data(), controls.mutable_view(), NULL, 0, n);
  return controls;
}

PackedControls OFRLevelOrderControls(
    const PackedControls &controls,
    size_t n,
    size_t n_left,
    size_t n_right)
{
  ValidateCapacities(n, n_left, n_right);
  if (!IsBalancedPowerOfTwo(n, n_left, n_right))
    throw std::invalid_argument("Level-order OFR requires balanced power-of-two capacities");
  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  if (controls.size() != required)
    throw std::length_error("OFR control array length mismatch");

  PackedControls level_controls(required);
  const size_t next = WriteLevelOrderControls(
      controls, &level_controls, n, n / 2, 0, 1, 0, 0);
  if (next != required)
    throw std::logic_error("OFR level-order conversion mismatch");
  return level_controls;
}

PackedControls OFRPostOrderControls(
    const PackedControls &controls,
    size_t n,
    size_t n_left,
    size_t n_right)
{
  return OFRPostOrderControls(controls.view(),
                              n, n_left, n_right);
}

PackedControls OFRPostOrderControls(
    PackedControlView controls,
    size_t n, size_t n_left, size_t n_right)
{
  ValidateCapacities(n, n_left, n_right);
  if (!IsBalancedPowerOfTwo(n, n_left, n_right))
    throw std::invalid_argument("Postorder OFR requires balanced power-of-two capacities");
  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  if (controls.size() != required)
    throw std::length_error("OFR control array length mismatch");

  std::vector<size_t> starts(n);
  if (BuildDfsControlStarts(n, 1, 0, 0, &starts) != required)
    throw std::logic_error("OFR DFS control layout mismatch");
  PackedControls postorder_controls(required);
  const size_t next = WritePostOrderFromDfs(
      controls, starts, &postorder_controls, 0, n, 0);
  if (next != postorder_controls.size())
    throw std::logic_error("OFR postorder conversion mismatch");
  return postorder_controls;
}

void OFRApplyInPlace(unsigned char *data,
                     const PackedControls &controls,
                     size_t n,
                     size_t n_left,
                     size_t n_right,
                     size_t block_size)
{
  ValidateCapacities(n, n_left, n_right);
  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  if (controls.size() != required)
    throw std::length_error("OFR control array length mismatch");
  OFRApplyPreparedInPlace(data, controls, n, n_left, n_right, block_size);
}

void OFRApplyPreparedInPlace(unsigned char *data,
                             const PackedControls &controls,
                             size_t n,
                             size_t n_left,
                             size_t n_right,
                             size_t block_size)
{
  OFRApplyPreparedInPlace(data, controls.view(),
                          n, n_left, n_right, block_size);
}

void OFRApplyPreparedInPlace(unsigned char *data,
                             PackedControlView controls,
                             size_t n,
                             size_t n_left,
                             size_t n_right,
                             size_t block_size)
{
  ValidateCapacities(n, n_left, n_right);
  size_t data_bytes = 0;
  if (data == NULL || block_size == 0 ||
      MulOverflowSize(n, block_size, &data_bytes))
    throw std::invalid_argument("Invalid OFR data dimensions");
  (void)data_bytes;
  if (controls.size() != OFRControlCountImpl(n, n_left, n_right))
    throw std::length_error("OFR control array length mismatch");
  if (n_left == 0 || n_right == 0)
  {
    if (controls.size() != 0)
      throw std::logic_error("OFR control consumption mismatch");
    return;
  }

  const size_t next = OFRApplyStrided(
      data, controls, n, n_left, n_right, block_size, 1, 0);
  if (next != controls.size())
    throw std::logic_error("OFR control consumption mismatch");
}

void OFRApplyLevelOrderedInPlace(
    unsigned char *data,
    const PackedControls &level_controls,
    size_t n,
    size_t n_left,
    size_t n_right,
    size_t block_size)
{
  ValidateCapacities(n, n_left, n_right);
  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  if (level_controls.size() != required)
    throw std::length_error("OFR control array length mismatch");
  OFRApplyPreparedLevelOrderedInPlace(
      data, level_controls, n, n_left, n_right, block_size);
}

void OFRApplyPreparedLevelOrderedInPlace(
    unsigned char *data,
    const PackedControls &level_controls,
    size_t n,
    size_t n_left,
    size_t n_right,
    size_t block_size)
{
  ValidateCapacities(n, n_left, n_right);
  size_t data_bytes = 0;
  if (!IsBalancedPowerOfTwo(n, n_left, n_right) ||
      data == NULL || block_size == 0 ||
      MulOverflowSize(n, block_size, &data_bytes))
    throw std::invalid_argument("Invalid level-order OFR dimensions");
  (void)data_bytes;

  if (level_controls.size() != OFRControlCountImpl(n, n_left, n_right))
    throw std::length_error("OFR control array length mismatch");

#ifndef BEFTS_MODE
  if (block_size == 4)
    ApplyLevelOrderedWithStyle<OFORK_4>(
        data, level_controls.view(), n, block_size);
  else if (block_size == 8)
    ApplyLevelOrderedWithStyle<OFORK_8>(
        data, level_controls.view(), n, block_size);
  else if (block_size == 12)
    ApplyLevelOrderedWithStyle<OFORK_12>(
        data, level_controls.view(), n, block_size);
  else if (block_size == 16)
    ApplyLevelOrderedWithStyle<OFORK_16>(
        data, level_controls.view(), n, block_size);
  else if (block_size == 24)
    ApplyLevelOrderedWithStyle<OFORK_24>(
        data, level_controls.view(), n, block_size);
  else if (block_size >= 16 && block_size % 16 == 0)
    ApplyLevelOrderedWithStyle<OFORK_16X>(
        data, level_controls.view(), n, block_size);
  else if (block_size >= 24 && block_size % 16 == 8)
    ApplyLevelOrderedWithStyle<OFORK_8_16X>(
        data, level_controls.view(), n, block_size);
  else
#endif
    ApplyLevelOrderedGates(data, level_controls.view(), n, block_size,
                           GenericGate());

}

void OFRApplyPostOrderInPlace(
    unsigned char *data,
    const PackedControls &postorder_controls,
    size_t n,
    size_t n_left,
    size_t n_right,
    size_t block_size)
{
  ValidateCapacities(n, n_left, n_right);
  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  if (postorder_controls.size() != required)
    throw std::length_error("OFR control array length mismatch");
  OFRApplyPreparedPostOrderInPlace(
      data, postorder_controls, n, n_left, n_right, block_size);
}

void OFRApplyPreparedPostOrderInPlace(
    unsigned char *data,
    const PackedControls &postorder_controls,
    size_t n,
    size_t n_left,
    size_t n_right,
    size_t block_size)
{
  OFRApplyPreparedPostOrderInPlace(
      data, postorder_controls.view(),
      n, n_left, n_right, block_size);
}

void OFRApplyPreparedPostOrderInPlace(
    unsigned char *data, PackedControlView postorder_controls, size_t n, size_t n_left, size_t n_right,
    size_t block_size)
{
  ValidateCapacities(n, n_left, n_right);
  size_t data_bytes = 0;
  if (!IsBalancedPowerOfTwo(n, n_left, n_right) ||
      data == NULL || block_size == 0 ||
      MulOverflowSize(n, block_size, &data_bytes))
    throw std::invalid_argument("Invalid postorder OFR dimensions");
  (void)data_bytes;

  if (postorder_controls.size() != OFRControlCountImpl(n, n_left, n_right))
    throw std::length_error("OFR control array length mismatch");

  PackedControlCursor control_data(postorder_controls);
  size_t next = 0;
#ifndef BEFTS_MODE
  if (block_size == 4)
    next = ApplyPostOrderGates(data, control_data, n, block_size, 0,
                               StyledGate<OFORK_4>());
  else if (block_size == 8)
    next = ApplyPostOrderGates(data, control_data, n, block_size, 0,
                               StyledGate<OFORK_8>());
  else if (block_size == 12)
    next = ApplyPostOrderGates(data, control_data, n, block_size, 0,
                               StyledGate<OFORK_12>());
  else if (block_size == 16)
    next = ApplyPostOrderGates(data, control_data, n, block_size, 0,
                               StyledGate<OFORK_16>());
  else if (block_size == 24)
    next = ApplyPostOrderGates(data, control_data, n, block_size, 0,
                               StyledGate<OFORK_24>());
  else if (block_size >= 16 && block_size % 16 == 0 &&
           block_size <= std::numeric_limits<uint32_t>::max())
    next = ApplyPostOrderGates(data, control_data, n, block_size, 0,
                               StyledGate<OFORK_16X>());
  else if (block_size >= 24 && block_size % 16 == 8 &&
           block_size <= std::numeric_limits<uint32_t>::max())
    next = ApplyPostOrderGates(data, control_data, n, block_size, 0,
                               StyledGate<OFORK_8_16X>());
  else
#endif
    next = ApplyPostOrderGates(data, control_data, n, block_size, 0,
                               GenericGate());

  if (next != postorder_controls.size())
    throw std::logic_error("OFR postorder control consumption mismatch");
}

void OFRApplyWordsInPlace(
    size_t *rows, size_t words_per_row,
    const PackedControls &controls, size_t position,
    size_t n, size_t n_left, size_t n_right)
{
  ValidateCapacities(n, n_left, n_right);
  size_t row_words = 0;
  if (rows == NULL || words_per_row == 0 ||
      MulOverflowSize(n, words_per_row, &row_words))
    throw std::invalid_argument("Invalid OFR membership dimensions");
  (void)row_words;
  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  if (position > controls.size() || required > controls.size() - position)
    throw std::length_error("OFR membership replay exceeds control tape");
  const size_t next = OFRApplyWordsStrided(
      rows, words_per_row,
      controls.view(position, required),
      n, n_left, n_right, 1, 0);
  if (next != required)
    throw std::logic_error("OFR membership replay count mismatch");
}

OFRControlReadResult OFRControlRead(const unsigned char *data,
                                    const PackedControls &controls,
                                    size_t n,
                                    size_t n_left,
                                    size_t n_right,
                                    size_t block_size,
                                    size_t position)
{
  ValidateCapacities(n, n_left, n_right);
  size_t data_bytes = 0;
  if (data == NULL || block_size == 0 ||
      MulOverflowSize(n, block_size, &data_bytes))
    throw std::invalid_argument("Invalid OFR data dimensions");
  (void)data_bytes;

  const size_t required = OFRControlCountImpl(n, n_left, n_right);
  if (position > controls.size() || required > controls.size() - position)
    throw std::length_error("OFR control read exceeds source array");

  std::vector<unsigned char> work(data, data + data_bytes);
  const size_t next = OFRApplyStrided(
      work.data(), controls.view(position, required),
      n, n_left, n_right, block_size, 1, 0);
  if (next != required)
    throw std::logic_error("OFR control consumption mismatch");
  OFRControlReadResult result;
  const size_t left_bytes = n_left * block_size;
  result.left.assign(work.begin(), work.begin() + left_bytes);
  result.right.assign(work.begin() + left_bytes, work.end());
  result.next_pos = position + next;
  return result;
}

OFRDataResult OFRApply(const unsigned char *data,
                       const PackedControls &controls,
                       size_t n,
                       size_t n_left,
                       size_t n_right,
                       size_t block_size)
{
  const size_t required = OFRControlCount(n, n_left, n_right);
  if (controls.size() != required)
    throw std::length_error("OFR control array length mismatch");
  OFRControlReadResult read = OFRControlRead(
      data, controls, n, n_left, n_right, block_size, 0);
  if (read.next_pos != required)
    throw std::logic_error("OFR control consumption mismatch");
  OFRDataResult result;
  result.left.swap(read.left);
  result.right.swap(read.right);
  return result;
}

OFRDataResult OFRCompact(const unsigned char *data,
                         const std::vector<uint8_t> &tags,
                         size_t n,
                         size_t n_left,
                         size_t n_right,
                         size_t block_size)
{
  const PackedControls controls = OFRControl(
      tags, n, n_left, n_right);
  return OFRApply(
      data, controls, n, n_left, n_right, block_size);
}

} // namespace ofr
